package com.ysbing.audioshare;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.os.Build;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Main {

    private static final int SOCKET_AUDIO_BUFFER_BYTES = 32 * 1024;

    public static void main(String[] args) {
        try {
            Options options = Options.parse(args);
            try (LocalSocket socket = connect(options.socketName, options.connectCode)) {
                InputStream inputStream = socket.getInputStream();

                // Read 8-byte format header: [uint32 sampleRate LE][uint16 channels LE][uint16 bitsPerSample LE]
                byte[] header = readFully(inputStream, 8);
                int sampleRate = readInt32LE(header, 0);
                int channels = readInt16LE(header, 4);

                int channelMask = (channels == 1)
                        ? AudioFormat.CHANNEL_OUT_MONO
                        : AudioFormat.CHANNEL_OUT_STEREO;

                play(inputStream, sampleRate, channelMask);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static LocalSocket connect(String abstractName, String connectCode) throws IOException {
        LocalSocket localSocket = new LocalSocket();
        localSocket.connect(new LocalSocketAddress(abstractName));
        try {
            localSocket.setReceiveBufferSize(SOCKET_AUDIO_BUFFER_BYTES);
        } catch (IOException ignored) {
            // Buffer tuning is optional and must not prevent the audio connection.
        }
        OutputStream outputStream = localSocket.getOutputStream();
        outputStream.write(connectCode.getBytes());
        outputStream.flush();
        return localSocket;
    }

    private static byte[] readFully(InputStream in, int len) throws IOException {
        byte[] buf = new byte[len];
        int offset = 0;
        while (offset < len) {
            int n = in.read(buf, offset, len - offset);
            if (n == -1) throw new IOException("FORMAT_HEADER_INCOMPLETE");
            offset += n;
        }
        return buf;
    }

    private static int readInt32LE(byte[] buf, int offset) {
        return (buf[offset] & 0xFF)
                | ((buf[offset + 1] & 0xFF) << 8)
                | ((buf[offset + 2] & 0xFF) << 16)
                | ((buf[offset + 3] & 0xFF) << 24);
    }

    private static int readInt16LE(byte[] buf, int offset) {
        return (buf[offset] & 0xFF) | ((buf[offset + 1] & 0xFF) << 8);
    }

    private static void play(InputStream inputStream, int sampleRate, int channelMask) throws IOException {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);

        int minBuffer = AudioTrack.getMinBufferSize(sampleRate, channelMask, AudioFormat.ENCODING_PCM_16BIT);
        // One minimum buffer of pre-roll plus one minimum buffer of headroom keeps
        // engine-period jitter covered without queueing several hundred ms of audio.
        int trackBuffer = minBuffer * 2;
        AudioTrack.Builder audioTrackBuilder = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelMask)
                        .build())
                .setBufferSizeInBytes(trackBuffer)
                .setTransferMode(AudioTrack.MODE_STREAM);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioTrackBuilder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY);
        }
        AudioTrack audioTrack = audioTrackBuilder.build();

        byte[] readBuf = new byte[minBuffer];

        int preRollTarget = minBuffer;
        int preRolled = 0;
        outer:
        while (preRolled < preRollTarget) {
            int n = inputStream.read(readBuf, 0, Math.min(readBuf.length, preRollTarget - preRolled));
            if (n == -1) break;
            int offset = 0;
            while (offset < n) {
                int written = audioTrack.write(readBuf, offset, n - offset);
                if (written < 0) break outer;
                offset += written;
            }
            preRolled += n;
        }

        audioTrack.play();
        try {
            while (!Thread.currentThread().isInterrupted()) {
                int bytesRead = inputStream.read(readBuf, 0, readBuf.length);
                if (bytesRead == -1) break;
                int offset = 0;
                while (offset < bytesRead) {
                    int written = audioTrack.write(readBuf, offset, bytesRead - offset);
                    if (written < 0) break;
                    offset += written;
                }
            }
        } finally {
            audioTrack.stop();
            audioTrack.release();
        }
    }
}
